#ifndef BFS_H
#define BFS_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <queue>
#include <string>
#include <iomanip>
using namespace std;

enum Color { WHITE, GRAY, BLACK };

// Airport information
struct Airport {
    int id;
    string name;
    string city;
    string country;
    int emergency;
    
    Airport() {
        id = 0;
        name = "";
        city = "";
        country = "";
        emergency = 0;
    }
};

class Graph {
private:
    int V;
    int Adj[20][20];     // adjacency matrix
    Color color[20];
    int dist[20];
    int parent[20];
    Airport A[20];       

public:
    Graph(int size = 20) {
        V = size;
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                Adj[i][j] = 0;
            }
        }
    }

    void setVertices(int v) { V = v; }
    int getVertices() const { return V; }

    void AddAirport(int idx, int id, string name, string city, string country, int em) {
        if (idx >= 0 && idx < V) {
            A[idx].id = id;
            A[idx].name = name;
            A[idx].city = city;
            A[idx].country = country;
            A[idx].emergency = em;
        }
    }

    void AddEdge(int u, int v) {
        if (u >= 0 && u < V && v >= 0 && v < V) {
            Adj[u][v] = 1;  // directed flight from u to v
        }
    }

    Airport getAirport(int idx) const {
        if (idx >= 0 && idx < V) return A[idx];
        return Airport();
    }

    void BFS(int s) {
        if (s < 0 || s >= V) return;

        for (int u = 0; u < V; u++) {
            color[u] = WHITE;
            dist[u] = -1;
            parent[u] = -1;
        }

        color[s] = GRAY;
        dist[s] = 0;

        queue<int> Q;
        Q.push(s);

        while (!Q.empty()) {
            int u = Q.front();
            Q.pop();

            // Explore all adjacent vertices
            for (int v = 0; v < V; v++) {
                if (Adj[u][v] == 1) {          // if edge exists
                    if (color[v] == WHITE) {   // if unvisited
                        color[v] = GRAY;
                        dist[v] = dist[u] + 1;
                        parent[v] = u;
                        Q.push(v);
                    }
                }
            }

            color[u] = BLACK;  // fully processed
        }
    }

    void PrintTraversal() const {
        cout << "\n==============================================\n";
        cout << "BFS TRAVERSAL TABLE\n";
        cout << "==============================================\n";
        
        cout << left << setw(15) << "Airport" 
             << setw(12) << "Distance" 
             << setw(15) << "Parent" << "\n";
        cout << "----------------------------------------------\n";

        for (int i = 0; i < V; i++) {
            cout << left << setw(15) << A[i].name;
            
            if (dist[i] == -1) 
                cout << setw(12) << "8";
            else 
                cout << setw(12) << dist[i];
            
            if (parent[i] == -1)
                cout << "None\n";
            else
                cout << A[parent[i]].name << "\n";
        }
    }

    void PrintRoute(int start, int dest) const {
        if (start < 0 || start >= V || dest < 0 || dest >= V) {
            cout << "\n Invalid airport indices!\n";
            return;
        }

        cout << "\n";

        if (dist[dest] == -1) {
            cout << "No route exists from " << A[start].name
                 << " to " << A[dest].name << "\n";
            return;
        }

        // Build path from dest to start
        int path[20];
        int idx = 0;
        int cur = dest;
        
        while (cur != -1) {
            path[idx++] = cur;
            cur = parent[cur];
        }

        // Print result
        cout << "Minimum stops from " << A[start].name 
             << " to " << A[dest].name << ": " << dist[dest] << "\n";
        
        cout << "Route: ";
        for (int i = idx - 1; i >= 0; i--) {
            cout << A[path[i]].name;
            if (i != 0) cout << " -> ";
        }
        cout << "\n";
    }

    int countDirectRoutes(int airportIdx) const {
        if (airportIdx < 0 || airportIdx >= V) return 0;
        
        int count = 0;
        for (int i = 0; i < V; i++) {
            if (Adj[airportIdx][i] == 1) count++;
        }
        return count;
    }

    void displayPossibleRoutes(int source) const {
        if (source < 0 || source >= V) return;
        
        cout << "\n=== Possible Routes from " << A[source].name << " ===\n";
        
        bool hasRoutes = false;
        for (int i = 0; i < V; i++) {
            if (dist[i] != -1 && i != source) {
                hasRoutes = true;
                cout << "To " << left << setw(15) << A[i].name 
                     << " : " << dist[i] << " stop(s)\n";
            }
        }
        
        if (!hasRoutes) {
            cout << "No reachable destinations from " << A[source].name << "\n";
        }
    }

    void displayOptimalRoute(int start, int dest) const {
        if (start < 0 || start >= V || dest < 0 || dest >= V) return;
        
        if (dist[dest] == -1) {
            cout << "\n No route available!\n";
            return;
        }

        cout << "\n=== Optimal Route Analysis ===\n";
        cout << "From: " << A[start].name << " (" << A[start].city << ")\n";
        cout << "To: " << A[dest].name << " (" << A[dest].city << ")\n";
        cout << "Number of stops: " << dist[dest] << "\n";
        
        int path[20];
        int idx = 0;
        int cur = dest;
        
        while (cur != -1) {
            path[idx++] = cur;
            cur = parent[cur];
        }
        
        cout << "\nDetailed Route:\n";
        for (int i = idx - 1; i >= 0; i--) {
            cout << "  " << (idx - i) << ". " << A[path[i]].name 
                 << " (" << A[path[i]].city << ", " << A[path[i]].country << ")";
            
            if (A[path[i]].emergency == 1) {
                cout << " [Emergency Services Available]";
            }
            
            if (i != 0) {
                cout << "\n     \n";
            } else {
                cout << "\n";
            }
        }
    }

    // Find airport index by name
    int findAirportByName(const string& name) const {
        for (int i = 0; i < V; i++) {
            if (A[i].name == name) return i;
        }
        return -1;
    }

    // Display all airports
    void displayAllAirports() const {
        cout << "\n=== Available Airports ===\n";
        for (int i = 0; i < V; i++) {
            cout << setw(2) << i << ". " << left << setw(15) << A[i].name 
                 << " (" << A[i].city << ", " << A[i].country << ")";
            if (A[i].emergency == 1) cout << " [Emergency]";
            cout << "\n";
        }
        cout << "==========================\n";
    }
};

// Load airports from file
bool loadAirports(Graph &g, const string& filename) {
    ifstream fin(filename.c_str());
    if (!fin) {
        return false;
    }

    int count = 0;
    string line;
    
    while (getline(fin, line) && count < 20) {
        if (line.empty() || line[0] == '#') continue;
        
        stringstream ss(line);
        int id, emergency;
        string name, city, country;
        
        if (ss >> id >> name >> city >> country >> emergency) {
            g.AddAirport(count, id, name, city, country, emergency);
            count++;
        }
    }
    
    fin.close();
    
    if (count == 0) {
        return false;
    }
    
    g.setVertices(count);
  //  cout << "Loaded " << count << " airports from " << filename << "\n";
    return true;
}

// Load routes from file
bool loadRoutes(Graph &g, const string& filename) {
    ifstream fin(filename.c_str());
    if (!fin) {
        return false;
    }

    int count = 0;
    string line;
    
    while (getline(fin, line)) {
        if (line.empty() || line[0] == '#') continue;
        
        stringstream ss(line);
        int u, v;
        
        if (ss >> u >> v) {
            g.AddEdge(u, v);
            count++;
        }
    }
    
    fin.close();
    
    if (count == 0) {
        return false;
    }
    
  //  cout << "Loaded " << count << " routes from " << filename << "\n";
    return true;
}

#endif
