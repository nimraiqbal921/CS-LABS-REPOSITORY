#ifndef AVL_H
#define AVL_H

#include <iostream>
#include "bst.h"
using namespace std;

class AVLNode {
public:
    Flight key;
    AVLNode* left;
    AVLNode* right;
    int height;
    AVLNode(Flight k) { key = k; left = right = NULL; height = 1; }
};

class AVL {
private:
    AVLNode* root;
    int rotations;

    int getHeight(AVLNode* n) { return n ? n->height : 0; }
    
    int getBalance(AVLNode* n) { 
        return n ? getHeight(n->left) - getHeight(n->right) : 0; 
    }

    void updateHeight(AVLNode* n) {
        if (n) n->height = 1 + max(getHeight(n->left), getHeight(n->right));
    }

    AVLNode* rightRotate(AVLNode* y) {
        AVLNode* x = y->left;
        AVLNode* T2 = x->right;
        x->right = y;
        y->left = T2;
        updateHeight(y);
        updateHeight(x);
        rotations++;
        return x;
    }

    AVLNode* leftRotate(AVLNode* x) {
        AVLNode* y = x->right;
        AVLNode* T2 = y->left;
        y->left = x;
        x->right = T2;
        updateHeight(x);
        updateHeight(y);
        rotations++;
        return y;
    }

    AVLNode* balance(AVLNode* node) {
        updateHeight(node);
        int bf = getBalance(node);

        // Left Left Case
        if (bf > 1 && getBalance(node->left) >= 0) {
            return rightRotate(node);
        }

        // Left Right Case
        if (bf > 1 && getBalance(node->left) < 0) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }

        // Right Right Case
        if (bf < -1 && getBalance(node->right) <= 0) {
            return leftRotate(node);
        }

        // Right Left Case
        if (bf < -1 && getBalance(node->right) > 0) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }

        return node;
    }

    AVLNode* insertRec(AVLNode* node, Flight key) {
        if (!node) return new AVLNode(key);
        
        if (key.getFlightID() < node->key.getFlightID()) 
            node->left = insertRec(node->left, key);
        else if (key.getFlightID() > node->key.getFlightID()) 
            node->right = insertRec(node->right, key);
        else 
            return node;

        return balance(node);
    }

    void inorderHelper(AVLNode* node) {
        if (!node) return;
        inorderHelper(node->left);
        node->key.display();
        inorderHelper(node->right);
    }

    void deleteTree(AVLNode* node) {
        if (!node) return;
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }

    AVLNode* searchRec(AVLNode* node, int id, int &steps) {
        if (!node) return NULL;
        steps++;
        if (id == node->key.getFlightID()) return node;
        if (id < node->key.getFlightID()) return searchRec(node->left, id, steps);
        else return searchRec(node->right, id, steps);
    }

    AVLNode* minValueNode(AVLNode* node) {
        while (node && node->left) 
            node = node->left;
        return node;
    }

    AVLNode* deleteNode(AVLNode* node, int id) {
        if (!node) return node;

        if (id < node->key.getFlightID()) {
            node->left = deleteNode(node->left, id);
        } 
        else if (id > node->key.getFlightID()) {
            node->right = deleteNode(node->right, id);
        } 
        else {
            if (!node->left || !node->right) {
                AVLNode* temp = node->left ? node->left : node->right;
                
                if (!temp) {
                    temp = node;
                    node = NULL;
                } else {
                    *node = *temp;
                }
                delete temp;
            } 
            else {
                AVLNode* temp = minValueNode(node->right);
                node->key = temp->key;
                node->right = deleteNode(node->right, temp->key.getFlightID());
            }
        }

        if (!node) return node;
        return balance(node);
    }

    void saveTreeStructure(AVLNode* u, ofstream &fout) {
        if (!u) return;
        
        if (u->left) saveTreeStructure(u->left, fout);
        
        fout << "Node ID: " << u->key.getFlightID() 
             << " (" << u->key.getDestination() << ")\n";
        fout << "Height: " << u->height << "\n";
        
        fout << "Left Child: ";
        if (u->left) {
            fout << "ID " << u->left->key.getFlightID() 
                 << " (" << u->left->key.getDestination() << ")\n";
        } else {
            fout << "NULL\n";
        }
        
        fout << "Right Child: ";
        if (u->right) {
            fout << "ID " << u->right->key.getFlightID() 
                 << " (" << u->right->key.getDestination() << ")\n";
        } else {
            fout << "NULL\n";
        }
        
        fout << "\n";
        
        if (u->right) saveTreeStructure(u->right, fout);
    }

public:
    AVL() { root = NULL; rotations = 0; }
    ~AVL() { deleteTree(root); }

    void insert(Flight key) { 
        root = insertRec(root, key); 
    }

    AVLNode* search(int id, int &steps) { 
        steps = 0; 
        return searchRec(root, id, steps); 
    }

    void deleteKey(int id) { 
        root = deleteNode(root, id); 
    }

    void inorder() { 
        if (!root) { 
            cout << "No flights in AVL.\n"; 
            return; 
        } 
        inorderHelper(root); 
    }

    void printAVL() { 
        inorderHelper(root); 
        cout << "Total rotations so far: " << rotations << endl; 
    }

    int getRotationCount() { return rotations; }
    void clearRotations() { rotations = 0; }

    void saveTreeStructureToStream(ofstream &fout) {
        if (!root) {
            fout << "AVL is empty.\n";
        } else {
            if (root->left) saveTreeStructure(root->left, fout);
            
            fout << "Root: ID " << root->key.getFlightID() 
                 << " (" << root->key.getDestination() << ")\n";
            fout << "Height: " << root->height << "\n";
            
            fout << "Left Child: ";
            if (root->left) {
                fout << "ID " << root->left->key.getFlightID() 
                     << " (" << root->left->key.getDestination() << ")\n";
            } else {
                fout << "NULL\n";
            }
            
            fout << "Right Child: ";
            if (root->right) {
                fout << "ID " << root->right->key.getFlightID() 
                     << " (" << root->right->key.getDestination() << ")\n";
            } else {
                fout << "NULL\n";
            }
            
            fout << "\n";
            
            if (root->right) saveTreeStructure(root->right, fout);
        }
    }
};

#endif
