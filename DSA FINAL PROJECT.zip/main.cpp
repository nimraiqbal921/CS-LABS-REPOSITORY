#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "bst.h"
#include "avl.h"
#include "bfs.h"

using namespace std;

const string FILENAME = "flights.txt";
const string AIRPORTS_FILE = "airports.txt";
const string ROUTES_FILE = "routes.txt";

void createDefaultAirportsFile() {
    ifstream test(AIRPORTS_FILE.c_str());
    if (test.good()) {
        test.close();
        return; 
    }
    
    ofstream fout(AIRPORTS_FILE.c_str());
    if (!fout) {
        cout << "Error: Cannot create " << AIRPORTS_FILE << "\n";
        return;
    }
    
    fout << "# airports.txt\n";
    fout << "# Format: id name city country emergency(1=yes, 0=no)\n\n";
    fout << "101 Karachi Karachi Pakistan 1\n";
    fout << "102 Lahore Lahore Pakistan 1\n";
    fout << "103 Islamabad Islamabad Pakistan 1\n";
    fout << "104 Peshawar Peshawar Pakistan 0\n";
    fout << "105 Quetta Quetta Pakistan 0\n";
    fout << "106 Multan Multan Pakistan 0\n";
    fout << "107 Faisalabad Faisalabad Pakistan 0\n";
    fout << "108 Sialkot Sialkot Pakistan 0\n";
    fout << "109 Skardu Skardu Pakistan 0\n";
    fout << "110 Dubai Dubai UAE 1\n";
    
    fout.close();
    cout << "Created default " << AIRPORTS_FILE << "\n";
}

void createDefaultRoutesFile() {
    ifstream test(ROUTES_FILE.c_str());
    if (test.good()) {
        test.close();
        return; 
    }
    
    ofstream fout(ROUTES_FILE.c_str());
    if (!fout) {
        cout << "Error: Cannot create " << ROUTES_FILE << "\n";
        return;
    }
    
    fout << "# routes.txt\n";
    fout << "# Format: source_index destination_index (directed edge)\n\n";
    fout << "# Karachi (0) connections\n";
    fout << "0 1\n0 2\n0 9\n\n";
    fout << "# Lahore (1) connections\n";
    fout << "1 0\n1 2\n1 3\n1 8\n\n";
    fout << "# Islamabad (2) connections\n";
    fout << "2 0\n2 1\n2 3\n2 4\n\n";
    fout << "# Peshawar (3) connections\n";
    fout << "3 2\n3 1\n\n";
    fout << "# Quetta (4) connections\n";
    fout << "4 2\n4 0\n\n";
    fout << "# Multan (5) connections\n";
    fout << "5 0\n5 1\n\n";
    fout << "# Faisalabad (6) connections\n";
    fout << "6 1\n6 2\n\n";
    fout << "# Sialkot (7) connections\n";
    fout << "7 1\n\n";
    fout << "# Skardu (8) connections\n";
    fout << "8 1\n8 2\n\n";
    fout << "# Dubai (9) connections\n";
    fout << "9 0\n9 1\n9 2\n";
    
    fout.close();
    cout << "Created default " << ROUTES_FILE << "\n";
}


void loadFlights(BST &bst, AVL &avl) {
    ifstream fin(FILENAME.c_str());
    if (!fin) return;

    string line;
    while (true) {
        if (!getline(fin, line)) break;
        if (line.size() == 0) continue;
        
        if (line.find("====") != string::npos || 
            line.find("ROOT:") != string::npos ||
            line.find("--") != string::npos) {
            continue;
        }

        string token;
        int id = 0;
        {
            stringstream ss(line);
            ss >> token;
            if (token.find("FLIGHT_ID") == string::npos) {
                continue;
            }
            size_t pos = line.find(":");
            if (pos != string::npos) {
                string val = line.substr(pos + 1);
                stringstream ss2(val);
                ss2 >> id;
            } else continue;
        }

        // Check if ID already exists
        int dummySteps = 0;
        if (bst.search(id, dummySteps) != NULL) {
            cout << "Warning: Duplicate Flight ID " << id << " found in file. Skipping...\n";
            for (int i = 0; i < 6; i++) getline(fin, line);
            continue;
        }

        Flight f;
        f.setFlightID(id);

        // DESTINATION
        if (!getline(fin, line)) break;
        {
            size_t pos = line.find(":");
            string val = (pos != string::npos) ? line.substr(pos + 1) : line;
            while (val.size() && val[0] == ' ') val.erase(0,1);
            f.setDestination(val);
        }

        // DEPARTURE
        if (!getline(fin, line)) break;
        {
            size_t pos = line.find(":");
            string val = (pos != string::npos) ? line.substr(pos + 1) : line;
            while (val.size() && val[0] == ' ') val.erase(0,1);
            stringstream ss(val);
            int h=0, m=0; string am="AM";
            ss >> h >> m >> am;
            f.setDepartureTime(h, m, am);
        }

        // DURATION
        if (!getline(fin, line)) break;
        {
            size_t pos = line.find(":");
            string val = (pos != string::npos) ? line.substr(pos + 1) : line;
            while (val.size() && val[0] == ' ') val.erase(0,1);
            stringstream ss(val);
            int dh=0, dm=0;
            ss >> dh >> dm;
            f.setDuration(dh, dm);
        }

        // ARRIVAL
        if (!getline(fin, line)) break;
        {
            size_t pos = line.find(":");
            string val = (pos != string::npos) ? line.substr(pos + 1) : line;
            while (val.size() && val[0] == ' ') val.erase(0,1);
            stringstream ss(val);
            int h=0, m=0; string am="AM";
            ss >> h >> m >> am;
            f.setActualArrival(h, m, am);
        }

        // CLASS
        if (!getline(fin, line)) break;
        {
            size_t pos = line.find(":");
            string val = (pos != string::npos) ? line.substr(pos + 1) : line;
            while (val.size() && val[0] == ' ') val.erase(0,1);
            f.setClass(val);
        }

        // STATUS
        if (!getline(fin, line)) break;
        {
            size_t pos = line.find(":");
            string val = (pos != string::npos) ? line.substr(pos + 1) : line;
            while (val.size() && val[0] == ' ') val.erase(0,1);
            f.flightStatus = val;
        }

        getline(fin, line);

        f.calculateETA();
        f.calculateStatus();

        bst.insert(new BSTNode(f));
        avl.insert(f);
    }

    fin.close();
}

void saveFlightsWithStructure(BST &bst, AVL &avl) {
    bst.saveToFile(FILENAME);
    
    ofstream fout(FILENAME.c_str(), ios::app);
    if (!fout) {
        cout << "Cannot open file for appending tree structures!\n";
        return;
    }
    
    fout << "\n\n";
    fout << "========================================\n";
    fout << "       TREE STRUCTURES\n";
    fout << "========================================\n\n";
    
    // Save BST structure
    fout << "--- BST STRUCTURE ---\n";
    BSTNode* bstRoot = bst.getRoot();
    if (!bstRoot) {
        fout << "BST is empty.\n";
    } else {
        fout << "ROOT: ID=" << bstRoot->key.getFlightID() 
             << " (" << bstRoot->key.getDestination() << ")\n";
        bst.saveTreeStructureToStream(fout);
    }
    
    fout << "\n--- AVL STRUCTURE ---\n";
    avl.saveTreeStructureToStream(fout);
    fout << "Total Rotations: " << avl.getRotationCount() << "\n";
    
    fout.close();
}

void printMenu() {
    cout << "\n------------------------------\n";
    cout << "   Flight Management System\n";
    cout << "------------------------------\n";
    cout << "1. Add New Flight (BST)\n";
    cout << "2. Search Flight (BST)\n";
    cout << "3. Delete Flight (BST)\n";
    cout << "4. Display All Flights (BST)\n";
    cout << "5. Display Flights (AVL) + Rotation Info\n";
    cout << "6. Compare Search Time (BST vs AVL)\n";
    cout << "7. Plan Trip from Airport A to B\n";
    cout << "8. Exit\n";
    cout << "Enter your choice: ";
}

int main() {
    BST flightBST;
    AVL flightAVL;
    Graph airportGraph;
    bool airportsLoaded = false;
    bool routesLoaded = false;

    createDefaultAirportsFile();
    createDefaultRoutesFile();

loadFlights(flightBST, flightAVL);

// Load airports and routes for BFS
airportsLoaded = loadAirports(airportGraph, AIRPORTS_FILE);

if (airportsLoaded) {
    routesLoaded = loadRoutes(airportGraph, ROUTES_FILE);
}
 
    cout << "\n";

    int choice = 0;
    while (true) {
        printMenu();
        if (!(cin >> choice)) { 
            cin.clear(); 
            string skip; 
            getline(cin, skip); 
            continue; 
        }
        if (choice == 8) break;

        if (choice == 1) {
            Flight f;
            int id; 
            string dest, cls, depAM, arrAM;
            int depH, depM, durH, durM, arrH, arrM;

            cout << "\n--- Add New Flight ---\n";
            cout << "Enter Flight ID: "; 
            cin >> id;
            
            // Check for duplicate ID
            int dummySteps = 0;
            if (flightBST.search(id, dummySteps) != NULL) { 
                cout << "Error: Flight ID already exists! Please use a unique ID.\n"; 
                continue; 
            }

            cout << "Enter Destination: "; 
            cin >> ws; 
            getline(cin, dest);

            cout << "Enter Class (Economy/Business/First): "; 
            cin >> cls;

            // Validated Departure Input
            do { 
                cout << "Enter Departure Hour (1-12): "; 
                cin >> depH; 
                if (!isValidHour(depH)) 
                    cout << "Invalid! Hour must be between 1 and 12.\n";
            } while (!isValidHour(depH));

            do { 
                cout << "Enter Departure Minute (0-59): "; 
                cin >> depM; 
                if (!isValidMinute(depM)) 
                    cout << "Invalid! Minute must be between 0 and 59.\n";
            } while (!isValidMinute(depM));

            do { 
                cout << "Enter Departure AM/PM: "; 
                cin >> depAM; 
                if (!isValidAMPM(depAM)) 
                    cout << "Invalid! Enter AM or PM.\n";
            } while (!isValidAMPM(depAM));

            // Duration Input
            do { 
                cout << "Enter Duration Hour: "; 
                cin >> durH; 
                if (durH < 0) 
                    cout << "Invalid! Duration cannot be negative.\n";
            } while (durH < 0);

            do { 
                cout << "Enter Duration Minute (0-59): "; 
                cin >> durM; 
                if (!isValidMinute(durM)) 
                    cout << "Invalid! Minute must be between 0 and 59.\n";
            } while (!isValidMinute(durM));

            // Validated Arrival Input
            do { 
                cout << "Enter Arrival Hour (1-12): "; 
                cin >> arrH; 
                if (!isValidHour(arrH)) 
                    cout << "Invalid! Hour must be between 1 and 12.\n";
            } while (!isValidHour(arrH));

            do { 
                cout << "Enter Arrival Minute (0-59): "; 
                cin >> arrM; 
                if (!isValidMinute(arrM)) 
                    cout << "Invalid! Minute must be between 0 and 59.\n";
            } while (!isValidMinute(arrM));

            do { 
                cout << "Enter Arrival AM/PM: "; 
                cin >> arrAM; 
                if (!isValidAMPM(arrAM)) 
                    cout << "Invalid! Enter AM or PM.\n";
            } while (!isValidAMPM(arrAM));

            f.setFlightID(id);
            f.setDestination(dest);
            f.setClass(cls);
            f.setDepartureTime(depH, depM, depAM);
            f.setDuration(durH, durM);
            f.setActualArrival(arrH, arrM, arrAM);
            f.calculateETA();
            f.calculateStatus();

            flightBST.insert(new BSTNode(f));
            flightAVL.insert(f);

            saveFlightsWithStructure(flightBST, flightAVL);
            cout << "\nFlight added successfully to both BST and AVL!\n";
        }
        else if (choice == 2) {
            int id; 
            cout << "\nEnter Flight ID to search: "; 
            cin >> id;
            int bstSteps = 0;
            BSTNode* found = flightBST.search(id, bstSteps);
            if (found) { 
                cout << "\n--- Flight Found ---\n";
                found->key.display(); 
                cout << "BST Search Steps: " << bstSteps << endl; 
            }
            else cout << "\nFlight not found!\n";
        }
        else if (choice == 3) {
            int id; 
            cout << "\nEnter Flight ID to delete: "; 
            cin >> id;
            int bstSteps = 0;
            BSTNode* found = flightBST.search(id, bstSteps);
            if (!found) { 
                cout << "\nFlight not found!\n"; 
            }
            else {
                flightBST.tree_delete(found);
                flightAVL.deleteKey(id);
                saveFlightsWithStructure(flightBST, flightAVL);
                cout << "\nFlight deleted successfully from both BST and AVL!\n";
            }
        }
        else if (choice == 4) {
            cout << "\n--- All Flights (BST Inorder) ---\n";
            flightBST.inorder();
        }
        else if (choice == 5) {
            cout << "\n--- All Flights (AVL Inorder) ---\n";
            flightAVL.inorder();
            cout << "\nTotal AVL Rotations: " << flightAVL.getRotationCount() << endl;
        }
        else if (choice == 6) {
            int id; 
            cout << "\nEnter Flight ID to compare search: "; 
            cin >> id;
            int bstSteps = 0, avlSteps = 0;
            BSTNode* bstFound = flightBST.search(id, bstSteps);
            AVLNode* avlFound = flightAVL.search(id, avlSteps);
            
            cout << "\n--- Search Comparison ---\n";
            if (!bstFound && !avlFound) {
                cout << "Flight ID " << id << " not found in either tree.\n";
            } else {
                cout << "Flight found!\n";
                cout << "BST Steps: " << bstSteps << endl;
                cout << "AVL Steps: " << avlSteps << endl;
                if (bstSteps < avlSteps) {
                    cout << "BST was faster by " << (avlSteps - bstSteps) << " steps.\n";
                } else if (avlSteps < bstSteps) {
                    cout << "AVL was faster by " << (bstSteps - avlSteps) << " steps.\n";
                } else {
                    cout << "Both took equal steps.\n";
                }
            }
        }
        else if (choice == 7) {
            cout << "\n========================================\n";
            cout << "     TRIP PLANNING (BFS)\n";
            cout << "========================================\n";
            
            
            // Display available airports
            airportGraph.displayAllAirports();
            
            int start, dest;
            cout << "\nEnter START airport index: ";
            cin >> start;
            
            cout << "Enter DESTINATION airport index: ";
            cin >> dest;
            
            if (start < 0 || start >= airportGraph.getVertices() || 
                dest < 0 || dest >= airportGraph.getVertices()) {
                cout << "\n Invalid airport indices!\n";
                continue;
            }
            
            // Run BFS from start airport
            airportGraph.BFS(start);
            
            // Display comprehensive results
            airportGraph.PrintTraversal();
            
            cout << "\n";
            airportGraph.PrintRoute(start, dest);
            
            cout << "\n";
            airportGraph.displayPossibleRoutes(start);
            
            cout << "\n";
            airportGraph.displayOptimalRoute(start, dest);
        }
        else {
            cout << "\nInvalid choice! Please try again.\n";
        }
    }

    // Save on exit
    saveFlightsWithStructure(flightBST, flightAVL);
    cout << "\nAll data saved to " << FILENAME << "\n";
    cout << "Exiting. Goodbye!\n";
    return 0;
}
