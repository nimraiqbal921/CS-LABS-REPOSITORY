#ifndef BST_H
#define BST_H

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

enum RelationType { LESS, GREATER, EQUAL };

// Validation functions
bool isValidHour(int h) { return h >= 1 && h <= 12; }
bool isValidMinute(int m) { return m >= 0 && m <= 59; }
bool isValidAMPM(const string& s) { 
    return s == "AM" || s == "PM" || s == "am" || s == "pm"; 
}

class Flight {
private:
    int flightID;
    string destination;
    string classType;

public:
    int depHour, depMin;
    string depAMPM;
    int durationH, durationM;
    int etaHour, etaMin;
    string etaAM;
    int arrHour, arrMin;
    string arrAMPM;
    string flightStatus;

    Flight() {
        flightID = 0;
        destination = "";
        classType = "Economy";
        depHour = depMin = durationH = durationM = etaHour = etaMin = arrHour = arrMin = 0;
        depAMPM = arrAMPM = etaAM = "AM";
        flightStatus = "";
    }

    void setFlightID(int id) { flightID = id; }
    void setDestination(const string &d) { destination = d; }
    void setClass(const string &c) { classType = c; }
    void setDepartureTime(int h, int m, const string &am) { 
        depHour = h; depMin = m; depAMPM = am; 
    }
    void setDuration(int h, int m) { durationH = h; durationM = m; }
    void setActualArrival(int h, int m, const string &am) { 
        arrHour = h; arrMin = m; arrAMPM = am; 
    }

    int getFlightID() const { return flightID; }
    string getDestination() const { return destination; }
    string getClass() const { return classType; }

    RelationType ComparedTo(const Flight& other) const {
        if (flightID < other.flightID) return LESS;
        else if (flightID > other.flightID) return GREATER;
        else return EQUAL;
    }

    void calculateETA() {
        int dep24 = depHour % 12;
        if (depAMPM == "PM" || depAMPM == "pm") dep24 += 12;
        int depMinutes = dep24 * 60 + depMin;
        int durMinutes = durationH * 60 + durationM;
        int etaTotal = depMinutes + durMinutes;
        int eta24Hour = (etaTotal / 60) % 24;
        etaMin = etaTotal % 60;
        etaHour = eta24Hour % 12;
        if (etaHour == 0) etaHour = 12;
        etaAM = (eta24Hour >= 12) ? "PM" : "AM";
    }

    void calculateStatus() {
        int eta24 = etaHour % 12;
        if (etaAM == "PM" || etaAM == "pm") eta24 += 12;
        int etaTotal = eta24 * 60 + etaMin;
        int arr24 = arrHour % 12;
        if (arrAMPM == "PM" || arrAMPM == "pm") arr24 += 12;
        int arrTotal = arr24 * 60 + arrMin;
        int diff = arrTotal - etaTotal;
        if (diff < -5) flightStatus = "Early";
        else if (diff > 5) flightStatus = "Delayed";
        else flightStatus = "On-Time";
    }

    void display() const {
        cout << "Flight ID: " << flightID
             << " | Destination: " << destination
             << " | Departure: " << depHour << ":" << (depMin < 10 ? "0" : "") << depMin << " " << depAMPM
             << " | Duration: " << durationH << "h " << durationM << "m"
             << " | ETA: " << etaHour << ":" << (etaMin < 10 ? "0" : "") << etaMin << " " << etaAM
             << " | Arrival: " << arrHour << ":" << (arrMin < 10 ? "0" : "") << arrMin << " " << arrAMPM
             << " | Status: " << flightStatus
             << " | Class: " << classType << endl;
    }

    void saveToFile(ofstream &fout) const {
        fout << "FLIGHT_ID: " << flightID << "\n";
        fout << "DESTINATION: " << destination << "\n";
        fout << "DEPARTURE: " << depHour << " " << depMin << " " << depAMPM << "\n";
        fout << "DURATION: " << durationH << " " << durationM << "\n";
        fout << "ARRIVAL: " << arrHour << " " << arrMin << " " << arrAMPM << "\n";
        fout << "CLASS: " << classType << "\n";
        fout << "STATUS: " << flightStatus << "\n";
        fout << "---\n";
    }
};

class BSTNode {
public:
    Flight key;
    BSTNode* parent;
    BSTNode* left;
    BSTNode* right;
    BSTNode(const Flight &k) { key = k; parent = left = right = NULL; }
};

class BST {
private:
    BSTNode* root;

    void transplant(BSTNode* u, BSTNode* v) {
        if (!u->parent) root = v;
        else if (u == u->parent->left) u->parent->left = v;
        else u->parent->right = v;
        if (v) v->parent = u->parent;
    }

    BSTNode* minimum(BSTNode* u) {
        while (u->left) u = u->left;
        return u;
    }

    void inorderHelper(BSTNode* u) {
        if (!u) return;
        inorderHelper(u->left);
        u->key.display();
        inorderHelper(u->right);
    }

    void saveInorder(BSTNode* u, ofstream &fout) {
        if (!u) return;
        saveInorder(u->left, fout);
        u->key.saveToFile(fout);
        saveInorder(u->right, fout);
    }

    void saveTreeStructure(BSTNode* u, ofstream &fout) {
        if (!u) return;
        
        if (u->left) saveTreeStructure(u->left, fout);
        
        fout << "Node ID: " << u->key.getFlightID() 
             << " (" << u->key.getDestination() << ")\n";
        
        fout << "Left Child: ";
        if (u->left) {
            fout << "ID " << u->left->key.getFlightID() 
                 << " (" << u->left->key.getDestination() << ")\n";
        } else {
            fout << "NULL\n";
        }
        
        fout << "Right Child: ";
        if (u->right) {
            fout << "ID " << u->right->key.getFlightID() 
                 << " (" << u->right->key.getDestination() << ")\n";
        } else {
            fout << "NULL\n";
        }
        
        fout << "\n";
        
        if (u->right) saveTreeStructure(u->right, fout);
    }

    void deleteTree(BSTNode* node) {
        if (!node) return;
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }

public:
    BST() { root = NULL; }
    ~BST() { deleteTree(root); }

    void insert(BSTNode* z) {
        BSTNode* y = NULL;
        BSTNode* x = root;
        while (x) {
            y = x;
            if (z->key.getFlightID() < x->key.getFlightID()) x = x->left;
            else x = x->right;
        }
        z->parent = y;
        if (!y) root = z;
        else if (z->key.getFlightID() < y->key.getFlightID()) y->left = z;
        else y->right = z;
    }

    BSTNode* search(int id, int &steps) {
        steps = 0;
        BSTNode* x = root;
        while (x) {
            steps++;
            if (id < x->key.getFlightID()) x = x->left;
            else if (id > x->key.getFlightID()) x = x->right;
            else return x;
        }
        return NULL;
    }

    void tree_delete(BSTNode* z) {
        if (!z->left) transplant(z, z->right);
        else if (!z->right) transplant(z, z->left);
        else {
            BSTNode* y = minimum(z->right);
            if (y->parent != z) {
                transplant(y, y->right);
                y->right = z->right;
                y->right->parent = y;
            }
            transplant(z, y);
            y->left = z->left;
            y->left->parent = y;
        }
        delete z;
    }

    void inorder() { 
        if (!root) { cout << "No flights in BST.\n"; return; }
        inorderHelper(root); 
    }

    void saveToFile(const string &filename) {
        ofstream fout(filename.c_str());
        if (!fout) { cout << "Cannot open file for writing!\n"; return; }
        saveInorder(root, fout);
        fout.close();
    }

    void saveTreeStructureToStream(ofstream &fout) {
        if (!root) {
            fout << "BST is empty.\n";
        } else {
            if (root->left) saveTreeStructure(root->left, fout);
            
            fout << "Root: ID " << root->key.getFlightID() 
                 << " (" << root->key.getDestination() << ")\n";
            
            fout << "Left Child: ";
            if (root->left) {
                fout << "ID " << root->left->key.getFlightID() 
                     << " (" << root->left->key.getDestination() << ")\n";
            } else {
                fout << "NULL\n";
            }
            
            fout << "Right Child: ";
            if (root->right) {
                fout << "ID " << root->right->key.getFlightID() 
                     << " (" << root->right->key.getDestination() << ")\n";
            } else {
                fout << "NULL\n";
            }
            
            fout << "\n";
            
            if (root->right) saveTreeStructure(root->right, fout);
        }
    }

    BSTNode* getRoot() { return root; }
};

#endif
